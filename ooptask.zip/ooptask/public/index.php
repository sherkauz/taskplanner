<?php

error_reporting(-1);
ini_set('display_errors', 'Off');



require_once '../app/bootstrap.php';

// Init Core Library
$init = new Core();