<?php
    // Database Params
    define('DB_HOST','localhost');
    define('DB_USER','root');
    define('DB_PASS','');
    define('DB_NAME','oopmvc');
    define('DB_CHARSET','utf8');

    // App Root
    define('APP_ROOT', dirname(dirname(__FILE__)));
    // URL Root 
    define('URL_ROOT','http://oopwander');
    // Site Name
    define('SITE_NAME', 'Task planner');
    // App Version
    define('APP_VERSION', '1.0.1');
    define('APP_DATE', 'DEC 12, 2021');
    define('APP_DATE_TIME_FORMAT', 'd/m/Y H:i:s');
